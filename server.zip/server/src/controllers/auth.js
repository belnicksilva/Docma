const db = require('../db');
const {hash} = require('bcryptjs');
const {sign} = require('jsonwebtoken');
const {SECRET} = require('../constants');

exports.getUsers = async (req,res) => {
    try{
      const {rows}= await db.query('select user_id, email, created_at, firstname, lastname, departamento, profile, created_at,permission  from users2');
      return res.status(200).json({
        success:true,
        users:rows,
      })
    }catch (error){
        console.log(error.message);
    }
}

exports.updateUsers = async (req,res) =>{
  const {permission,departamento,profile,user_id} = req.body;

  try {
    await db.query('UPDATE users2 SET permission=$1,departamento=$2,profile=$3 WHERE user_id=$4',[permission,departamento,profile,user_id])
    return res.status(200).json({success:true,message:'User Updated'})
  } catch (error) {
    console.log(error.message);
      return res.status(500).json({
        error:error.message,
      })
  }
}

exports.register = async (req,res) => {
  const {email,password,firstName,lastName} = req.body;

  try{
    const hashedPassword = await hash(password,10);
    console.log("Validation passed");
    await db.query('insert into users2 (email,password,firstname,lastname) values ($1, $2, $3, $4)',[email, hashedPassword,firstName,lastName]);

    return res.status(201).json({success:true,message:'The registration was successful'})
    
  }catch (error){
      console.log(error.message);
      return res.status(500).json({
        error:error.message,
      })
  }
}

exports.login = async (req,res) =>{
  let user = req.user;
  payload = {
    id:user.user_id,
    email:user.email
  }
  
  try{
    const token = await sign(payload,SECRET )
    return res.status(200).cookie('token',token,{httpOnly:true}).json({
      success:true,
      message:'Logged in succefully',
    })

  }catch(error){
    console.log(error.message);
    return res.status(500).json({
      error:error.message,
    })
}}

exports.protected = async (req,res) => {
  try{
    return res.status(200).json({
      info:'protected info',
    })
  }catch (error){
      console.log(error.message);
  }
}

exports.logout = async (req,res) => {
  try{
    return res.status(200).clearCookie('token',{httpOnly:true}).json({
      success:true,
      message:'Logged out is succefully',
    })
    
  }catch(error){
    console.log(error.message);
    return res.status(500).json({
      error:error.message,
    })
  }
}