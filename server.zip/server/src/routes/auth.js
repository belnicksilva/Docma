const {Router} = require ('express');
const { getUsers,register, login, protected, logout,updateUsers } = require('../controllers/auth');
const {validationMiddleware}=require('../middlewares/validation-middleware');
const {registerValidation, loginValidation} = require('../validators/auth');
const {userAuth} = require('../middlewares/auth-middleware')

const router = Router();

router.get('/get-users',userAuth,getUsers);
router.put('/update-users',userAuth,updateUsers);
router.get('/protected',userAuth,protected);
router.post('/register', registerValidation, validationMiddleware, register)
router.post('/login', loginValidation, validationMiddleware,login)
router.get('/logout',logout)

module.exports = router