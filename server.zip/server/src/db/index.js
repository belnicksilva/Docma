const {Pool} = require('pg');
const {DB_PASSWORD,DB_PORT} = require('../constants');

const pool=new Pool({
    user:'postgres',
    host:'localhost',
    database:'Docma',
    password:DB_PASSWORD,
    port:DB_PORT
});

module.exports = {
    query:(text, params) =>pool.query(text,params),
}