const { check } = require('express-validator');
const db = require ('../db');
const {compare}=require('bcryptjs')

//password
const password = check('password').isLength({min: 6,max: 15}).withMessage('Password has to be between 6 and 15 characters');

//email
const email = check('email').isEmail().withMessage('Please provide a valid email.');

//firstname
const firtsName = check('firstName').notEmpty().trim().withMessage('Please provide your First Name.');

//firstname
const lastName = check('lastName').notEmpty().trim().withMessage('Please provide your Last Name.');

//check if emails exists
const emailExists = check('email').custom(async (value) =>{
    const {rows} = await db.query('SELECT * from users2 WHERE email = $1',[value,])
    if (rows.length){
        throw new Error('Email already exist.');
    }
})

//check if first and last name exist
const nameExist = check('firstName').custom(async (value,{req}) =>{
    const {rows} = await db.query('SELECT * from users2 WHERE firstname = $1 AND lastname = $2',[value,req.body.lastName,])
    let validLastName =  null;
    await rows.map(val=>{
        validLastName =  compare(req.body.lastName,val.lastname);
        console.log(rows.length);    
        if(rows.length&&!validLastName){      
            throw new Error('This First and Last name already exist.');
        }
    })
        
})

//login validation
const loginFieldsCheck = check('email').custom(async (value,{req})=>{
    const user = await db.query("SELECT * from users2 WHERE email = $1",[value,])
    if(!user.rows.length){
        throw new Error('Email does not exist.');
    }
    const validPassword = await compare(req.body.password, user.rows[0].password)
    if(!validPassword){
        throw new Error('Wrong password');
    }

    req.user = user.rows[0];
})

module.exports = {
    registerValidation: [firtsName,lastName,nameExist,email, password, emailExists],
    loginValidation:[loginFieldsCheck],
}