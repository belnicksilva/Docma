ALTER TABLE users2 ADD firstname VARCHAR(20);
ALTER TABLE users2 ADD lastname VARCHAR(20);
ALTER TABLE users2 ADD permission VARCHAR(11);

UPDATE users2 SET firstname='doc2' WHERE user_id=4;
UPDATE users2 SET firstname='docma' WHERE user_id=5;
UPDATE users2 SET firstname='test' WHERE user_id=6;

UPDATE users2 SET lastname='d2' WHERE user_id=4;
UPDATE users2 SET lastname='da' WHERE user_id=5;
UPDATE users2 SET lastname='tt' WHERE user_id=6;

ALTER TABLE users2 ADD lastname VARCHAR(20);

DELETE FROM users2 WHERE user_id > 6 AND user_id < 13;

UPDATE users2 SET profile=true;